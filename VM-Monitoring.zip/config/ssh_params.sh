export host="127.0.0.1"
export port="5050"
export user="gabriel"
